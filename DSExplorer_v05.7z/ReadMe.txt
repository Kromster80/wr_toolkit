------------------------------------------------------
Synetic DataSet Explorer v0.5
------------------------------------------------------

Description:
Tool for exploring Synetic datasets (*.ds, *.car, *.wrc and other)

Version History:
0.5     2022.12.14  Fixed handling of fake data type placed by AFC11Man (and others)
0.4     2022.11.25  Fixed quotes export for Google Sheets
0.3     2022.10.25  Fixed export issues with uneven entry count in COs
                    Added codepage for Polish, Hungarian, Czech
0.2     2022.10.25  Fixed updated data not being written on paste from clipboard
                    Added .scn files support (it is the same DS inside)
0.1     2022.10.25  Initial release
                    Browse all supported DS files in this and sub-folders
                    Copy/Paste to/from clipboard all CO text Values of the selected TB

If You have any questions, answers, comments, suggestions or requests - I'd be happy to get in touch.
Author: Krom
Discord: Krom#7629
E-mail: kromster80@gmail.com
Site: http://krom.reveur.de/