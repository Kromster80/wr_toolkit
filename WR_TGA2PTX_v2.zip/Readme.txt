----------------------------------------------------------------
"MBWR / WR2 / C11" command-line TGA2PTX converter v2
----------------------------------------------------------------

Description:
Command-line tool for TGA to PTX conversion.

Version history:
v2	07.12.17	Added batch conversion using *.tga
v0.1	04.07.27	First release

Have any questions, answers, comments ? Send me e-mail.
Author: Krom
E-mail: kromster80@gmail.com
Site: http://krom.reveur.de/